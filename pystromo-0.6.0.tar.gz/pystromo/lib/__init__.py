"""
	Modules in this package:
		config
		constants
		devices
		events
		ioctl
		mapping
	
	Scripts which may be useful under some circumstances:
		test-mapping.py
"""
