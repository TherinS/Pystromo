#!/usr/bin/env bash

cp -rf pystromo/ ~/.config/
