#!/usr/bin/env bash

python ~/.config/pystromo/pystromo-mon.py -v
#python ~/.config/pystromo/pystromo-mon.py -v -c ~/.config/pystromo/config/monitor.conf
